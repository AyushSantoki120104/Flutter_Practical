package com.example.preactical_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
